# QA — EP6 — abertura com entonação

- Master final: 66,00 s,1080 × 1920,30 fps, H.264/AAC estéreo.
- Volume integrado: −16,1 LUFS. QA do projeto aprovado em duração, resolução, fps, volume e 7/7 itens do gate.
- Nova interpretação com a mesma voz jovem original, usando modelo expressivo. Os pronomes ELE e MAS ELA ganharam destaque e pausas curtas. Voz não acelerada.
- Pausas adicionais de 120 ms após ELE e ELA; reforço suave de 2,2 dB nos trechos destacados.
- Abertura 4,9 s. Restante deslocado 1,9 s, mantendo duração relativa, diálogos, reações e encerramento “Em breve”.
- Os 1.833 quadros do corpo foram decodificados e comparados por hash: idênticos aos da versão anterior. PCM do restante do áudio copiado literalmente.
- Transcrição local reconheceu: “Ele vai se declarar, mas ela vai embora.” Os comandos de interpretação não foram falados.
- Cinema sentado, revelação do curso, falas simultâneas e pausa dramática preservados da versão visual já revisada.
- Sem votação, data de lançamento ou cena depois da cartela final.

647 caracteres de entrada acumulados sob o teto aprovado de 1.000. Nenhuma voz nova criada. A interpretação artística continua sujeita à escuta do autor. Nada publicado ou agendado.
