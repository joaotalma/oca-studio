# EP6 — A notícia — roteiro refeito

Final da temporada 1 · 65.972s · narração somente na abertura

## Contrato
Ele quer se declarar; ela precisa contar que vai mudar de estado. A entrega prepara a reaproximação: ela percebe que o magoou e toma a iniciativa do encontro. A oportunidade profissional é uma escolha legítima da Lua. O episódio entrega a notícia ao Tico, em vez de escondê-la para a T2.

## Direção com tempos reais

| Início–fim | Cena e intenção |
|---|---|
| 00:00.00–00:04.90 | Gancho: Tico e Lua apresentados em painéis simultâneos, com nomes. Ele vai se declarar; ela vai embora. |
| 00:04.90–00:09.48 | Áudio da Lua identificado sobre o carro: entrega até as 20h. São 19h41, GPS: 34 min. Tico pressiona TURBO. |
| 00:09.48–00:12.61 | Carro visto de trás acelera e cruza no vermelho, sem humanos visíveis. Letícia reage de dentro do veículo. |
| 00:12.61–00:25.70 | Tico chega às 19h55 orgulhoso. Entrega já concluída às 19h50. Ele entende a desconfiança; Lua reconhece a mágoa. Celular deitado na bancada, sem troca de pegada. |
| 00:25.70–00:32.97 | Três dias depois, ela o convida. Ele começa a prometer, confere a agenda e aceita. Sem compra de ingresso. |
| 00:32.97–00:36.67 | Cinema: os dois sentados em cadeiras, pernas dobradas, joelhos e pés completos. Doce compartilhado e olhares. |
| 00:36.67–00:41.88 | Ela precisa contar algo; ele também. Hesitação e contato visual. |
| 00:41.88–00:43.04 | Declaração e mudança se cruzam: Lua “Eu vou pra outro estado”, Tico “Eu te amo”. Legendas separadas; vozes em posições estéreo correspondentes aos personagens. |
| 00:43.04–00:44.19 | 1,15s de silêncio real, sem música nem efeitos. Tico entende o que ouviu. |
| 00:44.19–00:46.51 | “Doces da Lua.” Ele só então desloca os olhos para a fatia. O doce cabe inteiro no enquadramento. |
| 00:46.51–01:01.67 | Lua conta que se inscreveu no curso de confeitaria em Porto Alegre, que começa em 30 dias. “E a gente?” / “Não sei. Mas eu quis estar aqui.” Reação afetuosa e incerta. |
| 01:01.67–01:05.97 | Última cartela: SE VIRA, TICO / TEMPORADA 2 / EM BREVE. Sem votação, data ou cena depois. |

## Falas

| Início–fim | Quem | Texto |
|---|---|---|
| 00:05.00–00:06.46 | Lua | Preciso entregar até as oito. |
| 00:06.96–00:08.98 | Tico | Trinta e quatro minutos? Duvida de mim? |
| 00:09.98–00:11.51 | Letícia | Isso não estava no meu curso! |
| 00:12.96–00:14.52 | Tico | Cinco minutos adiantado! |
| 00:15.07–00:16.07 | Lua | O outro já entregou. |
| 00:16.87–00:18.20 | Tico | Você achou que eu não chegava. |
| 00:18.90–00:21.04 | Lua | Tico… eu precisava garantir. |
| 00:21.64–00:22.60 | Tico | É. Claro. |
| 00:26.10–00:27.89 | Lua | Sexta. Cinema às oito. Você pode? |
| 00:28.29–00:29.25 | Tico | Eu desmarco… |
| 00:30.65–00:31.67 | Tico | Às oito eu posso. |
| 00:36.67–00:38.78 | Lua | Tico, eu preciso te contar uma coisa. |
| 00:39.48–00:40.28 | Tico | Eu também. |
| 00:41.88–00:43.04 | Lua | Eu vou pra outro estado. |
| 00:41.94–00:42.97 | Tico | Eu te amo. |
| 00:44.19–00:45.16 | Tico | Doces da Lua. |
| 00:46.51–00:50.16 | Lua | Eu me inscrevi num curso de confeitaria. Em Porto Alegre. |
| 00:51.26–00:52.93 | Lua | Começa daqui a trinta dias. |
| 00:53.99–00:54.82 | Tico | E a gente? |
| 00:56.42–00:58.67 | Lua | Não sei. Mas eu quis estar aqui. |

## Decisões do autor aplicadas
- Entrega preservada como motivação do convite. Carro de costas no vermelho.
- Retiradas a compra dos ingressos, a frase “lambo os dedos” e a votação final.
- Cinema sentado com pernas completas. Contato visual na declaração; olhar ao doce apenas no disfarce.
- Curso revelado ao Tico neste episódio. T2 agora parte do fato de ambos saberem da mudança.
- Encerramento “Em breve”, sem20 de novembro ou outra data de lançamento.
- Vozes existentes do elenco:10 falas reaproveitadas,10 novas;249 novos caracteres,545 acumulados sob teto aprovado de 1.000.
- Pausas e fala do cinema ajustadas sem mudar o timbre; não foram criadas vozes novas.
- Ficção original: continuidade de episodios/ep06/pre_roteiro.md e decisões do autor nesta conversa de 11/11/2026. O novo desfecho substitui a premissa anterior de segredo do curso.




Abertura com interpretação contrastante: **ELE… vai se declarar. MAS ELA… vai embora.** Pronomes destacados, pausas curtas, sem acelerar a voz. A abertura dura 4,9 s; demais cenas e falas foram preservadas, deslocadas 1,9 s.
