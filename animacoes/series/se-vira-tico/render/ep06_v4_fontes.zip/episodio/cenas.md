# EP6 — Direção das cenas

| Início–fim | Cena e intenção |
|---|---|
| 00:00.00–00:04.90 | Gancho: Tico e Lua apresentados em painéis simultâneos, com nomes. Ele vai se declarar; ela vai embora. |
| 00:04.90–00:09.48 | Áudio da Lua identificado sobre o carro: entrega até as 20h. São 19h41, GPS: 34 min. Tico pressiona TURBO. |
| 00:09.48–00:12.61 | Carro visto de trás acelera e cruza no vermelho, sem humanos visíveis. Letícia reage de dentro do veículo. |
| 00:12.61–00:25.70 | Tico chega às 19h55 orgulhoso. Entrega já concluída às 19h50. Ele entende a desconfiança; Lua reconhece a mágoa. Celular deitado na bancada, sem troca de pegada. |
| 00:25.70–00:32.97 | Três dias depois, ela o convida. Ele começa a prometer, confere a agenda e aceita. Sem compra de ingresso. |
| 00:32.97–00:36.67 | Cinema: os dois sentados em cadeiras, pernas dobradas, joelhos e pés completos. Doce compartilhado e olhares. |
| 00:36.67–00:41.88 | Ela precisa contar algo; ele também. Hesitação e contato visual. |
| 00:41.88–00:43.04 | Declaração e mudança se cruzam: Lua “Eu vou pra outro estado”, Tico “Eu te amo”. Legendas separadas; vozes em posições estéreo correspondentes aos personagens. |
| 00:43.04–00:44.19 | 1,15s de silêncio real, sem música nem efeitos. Tico entende o que ouviu. |
| 00:44.19–00:46.51 | “Doces da Lua.” Ele só então desloca os olhos para a fatia. O doce cabe inteiro no enquadramento. |
| 00:46.51–01:01.67 | Lua conta que se inscreveu no curso de confeitaria em Porto Alegre, que começa em 30 dias. “E a gente?” / “Não sei. Mas eu quis estar aqui.” Reação afetuosa e incerta. |
| 01:01.67–01:05.97 | Última cartela: SE VIRA, TICO / TEMPORADA 2 / EM BREVE. Sem votação, data ou cena depois. |


Abertura com interpretação contrastante: **ELE… vai se declarar. MAS ELA… vai embora.** Pronomes destacados, pausas curtas, sem acelerar a voz. A abertura dura 4,9 s; demais cenas e falas foram preservadas, deslocadas 1,9 s.
