# Revisão autoral —11/11/2026

- Entrega preservada como motivação do convite.
- Farol com carro de costas, sem humanos visíveis.
- Sem compra de ingressos.
- Cinema sentado com pernas completas.
- Declaração e mudança simultâneas, legendadas separadamente.
- Silêncio real de 1,15 segundo antes do disfarce.
- Tico recebe a notícia do curso neste episódio.
- Sem votação; última cartela TEMPORADA 2 — EM BREVE, sem data.

A abertura foi corrigida após revisão independente: Lua aparece desde o gancho e seu áudio remoto é identificado para não ser confundida com Letícia. O close do doce foi aberto para preservar a fatia.
