# QA — EP6 refeito — A notícia

## Master final
- Duração: 64,10 s;1.923 quadros;1080 × 1920,30 fps;H.264 com AAC estéreo 48 kHz.
- Volume integrado medido: −16,2 LUFS (alvo −16 ±1).
- QA do projeto: aprovado em duração, resolução, fps, volume e 7/7 itens do gate.
- Sem erros de desenho; sem quadros repetidos não explicados, sem meia-segunda abaixo do limiar de movimento e sem saltos de imagem não declarados.
- Declarações simultâneas com duas legendas separadas. Posição estéreo acompanha os personagens: Tico à esquerda, Lua à direita.
- Silêncio dramático: 1,15 s. Mixagem com amostras zeradas no intervalo; trecho central do AAC medido com máximo de −91 dB.
- Vinte falas sincronizadas pelos timestamps da API; as dez novas foram conferidas por ASR local. A pontuação e a expansão de “pra/para” do ASR não substituíram o roteiro.

## Revisão independente
O revisor identificou que o gancho sobre o carro poderia confundir Letícia com Lua e que o doce ficava na borda do close. As correções foram aplicadas e reavaliadas em quadros extraídos do MP4 final: P1/P2 resolvidos, veredito visual “Ship”, sem impedimentos concretos nas correções examinadas. O revisor não ouviu o áudio; as medições de som não equivalem a uma avaliação subjetiva da interpretação.

## Conferência autoral
- Gancho identifica Tico e Lua. A fala remota no carro está marcada como áudio da Lua.
- Traseira do carro no farol vermelho, sem humanos visíveis.
- Chegada às 19h55; entrega concluída às 19h50. Desconfiança e mágoa compreensíveis.
- Celular deitado na bancada durante a conversa, sem pegada que troca de posição.
- Sem compra de ingresso. Convite leva diretamente ao cinema.
- Quadris apoiados, pernas completas, joelhos dobrados e pés visíveis nas cadeiras.
- Olhar dirigido ao interlocutor na declaração e à fatia somente no disfarce.
- Lua conta o curso de confeitaria em Porto Alegre ao Tico. A mudança já é conhecida por ambos ao fim da T1.
- Último quadro: TEMPORADA 2 — EM BREVE. Sem votação, data de lançamento ou cena posterior.

Ficção, personagens e som originais. Cinema só com luzes e reações; sem cenas de filmes ou músicas comerciais. Vozes fixas do ElevenLabs, nenhuma nova voz criada.249 novos caracteres;545 acumulados sob limite aprovado de 1.000. Não há promessa de viralização.

O autor assiste e publica. Nada foi publicado ou agendado.
